import { useState, useEffect, useRef } from 'react';

interface MarketData {
  symbol: string;
  price: number;
  change: number;
  timestamp: number;
}

interface WebSocketMessage {
  type: string;
  payload: any;
}

export function useWebSocket() {
  const [socket, setSocket] = useState<WebSocket | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [marketData, setMarketData] = useState<MarketData | null>(null);
  const reconnectAttempts = useRef(0);
  const maxReconnectAttempts = 5;

  useEffect(() => {
    const connectWebSocket = () => {
      try {
        const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
        const wsUrl = `${protocol}//${window.location.host}/ws`;
        const ws = new WebSocket(wsUrl);

        ws.onopen = () => {
          console.log('WebSocket connected');
          setIsConnected(true);
          setSocket(ws);
          reconnectAttempts.current = 0;
        };

        ws.onmessage = (event) => {
          try {
            const message: WebSocketMessage = JSON.parse(event.data);
            handleMessage(message);
          } catch (error) {
            console.error('Failed to parse WebSocket message:', error);
          }
        };

        ws.onclose = () => {
          console.log('WebSocket disconnected');
          setIsConnected(false);
          setSocket(null);

          // Attempt to reconnect
          if (reconnectAttempts.current < maxReconnectAttempts) {
            setTimeout(() => {
              reconnectAttempts.current++;
              console.log(`Reconnection attempt ${reconnectAttempts.current}`);
              connectWebSocket();
            }, Math.pow(2, reconnectAttempts.current) * 1000); // Exponential backoff
          }
        };

        ws.onerror = (error) => {
          console.error('WebSocket error:', error);
        };

      } catch (error) {
        console.error('Failed to create WebSocket connection:', error);
      }
    };

    const handleMessage = (message: WebSocketMessage) => {
      switch (message.type) {
        case 'connected':
          console.log('WebSocket connection confirmed');
          break;
        
        case 'market_data':
          setMarketData(message.payload);
          break;
        
        case 'trade_executed':
          console.log('Trade executed:', message.payload);
          // Handle trade notifications
          break;
        
        default:
          console.log('Unknown message type:', message.type);
      }
    };

    connectWebSocket();

    return () => {
      if (socket) {
        socket.close();
      }
    };
  }, []);

  const sendMessage = (message: WebSocketMessage) => {
    if (socket && socket.readyState === WebSocket.OPEN) {
      socket.send(JSON.stringify(message));
    } else {
      console.warn('WebSocket is not connected');
    }
  };

  const subscribeToSymbol = (symbol: string) => {
    sendMessage({
      type: 'subscribe',
      payload: { symbol }
    });
  };

  const unsubscribeFromSymbol = (symbol: string) => {
    sendMessage({
      type: 'unsubscribe',
      payload: { symbol }
    });
  };

  return {
    socket,
    isConnected,
    marketData,
    sendMessage,
    subscribeToSymbol,
    unsubscribeFromSymbol
  };
}
