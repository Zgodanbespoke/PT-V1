import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";

interface HeaderProps {
  analytics?: {
    portfolioValue: number;
  };
  isConnected: boolean;
  isLoading?: boolean;
}

export default function Header({ analytics, isConnected, isLoading }: HeaderProps) {
  return (
    <header className="bg-white border-b border-gray-200 px-6 py-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold text-gray-900">Trading Dashboard</h2>
          <p className="text-sm text-gray-600">Monitor your strategies and performance</p>
        </div>
        
        <div className="flex items-center space-x-4">
          <Badge 
            variant={isConnected ? "default" : "secondary"}
            className={isConnected ? "bg-green-100 text-green-800" : ""}
          >
            <div className={`w-2 h-2 rounded-full mr-2 ${
              isConnected ? "bg-green-600 animate-pulse" : "bg-gray-400"
            }`} />
            {isConnected ? "Live Market Data" : "Disconnected"}
          </Badge>
          
          <div className="text-right">
            <p className="text-sm text-gray-600">Portfolio Value</p>
            {isLoading ? (
              <Skeleton className="h-6 w-20" />
            ) : (
              <p className="text-lg font-semibold text-gray-900">
                ₹{analytics?.portfolioValue?.toLocaleString('en-IN') || '0'}
              </p>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
