import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Key, Info } from "lucide-react";

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  userId: number;
}

export default function AuthModal({ isOpen, onClose, userId }: AuthModalProps) {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState({
    clientId: "",
    apiKey: "",
    secret: "",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const response = await apiRequest('POST', '/api/auth/angel-one', {
        ...formData,
        userId
      });
      
      const result = await response.json();
      
      toast({
        title: "Authentication Successful",
        description: "Connected to Angel One SmartAPI",
      });
      
      // Invalidate user query to refresh authentication status
      await queryClient.invalidateQueries({ queryKey: [`/api/user/${userId}`] });
      
      onClose();
    } catch (error: any) {
      toast({
        title: "Authentication Failed",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
            <Key className="text-white text-2xl" />
          </div>
          <DialogTitle className="text-center text-2xl font-semibold">
            Angel One Authentication
          </DialogTitle>
          <p className="text-center text-gray-600">
            Connect your Angel One SmartAPI account
          </p>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="clientId">Client ID</Label>
            <Input
              id="clientId"
              name="clientId"
              type="text"
              value={formData.clientId}
              onChange={handleInputChange}
              placeholder="Your Angel One Client ID"
              required
              className="mt-1"
            />
          </div>
          
          <div>
            <Label htmlFor="apiKey">API Key</Label>
            <Input
              id="apiKey"
              name="apiKey"
              type="password"
              value={formData.apiKey}
              onChange={handleInputChange}
              placeholder="Your API Key"
              required
              className="mt-1"
            />
          </div>
          
          <div>
            <Label htmlFor="secret">Secret Key</Label>
            <Input
              id="secret"
              name="secret"
              type="password"
              value={formData.secret}
              onChange={handleInputChange}
              placeholder="Your Secret Key"
              required
              className="mt-1"
            />
          </div>
          
          <Button 
            type="submit" 
            className="w-full"
            disabled={isLoading}
          >
            {isLoading ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Connecting...
              </>
            ) : (
              <>
                <Key className="mr-2 h-4 w-4" />
                Connect Account
              </>
            )}
          </Button>
        </form>
        
        <Alert className="mt-4">
          <Info className="h-4 w-4" />
          <AlertDescription>
            <p className="font-medium">Secure Connection</p>
            <p className="text-sm">
              Your credentials are encrypted and stored securely. We use Angel One's official SmartAPI SDK.
            </p>
          </AlertDescription>
        </Alert>
      </DialogContent>
    </Dialog>
  );
}
