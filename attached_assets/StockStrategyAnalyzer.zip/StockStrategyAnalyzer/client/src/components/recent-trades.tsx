import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useQuery } from "@tanstack/react-query";
import { ExternalLink } from "lucide-react";

interface RecentTradesProps {
  userId: number;
}

export default function RecentTrades({ userId }: RecentTradesProps) {
  const { data: trades, isLoading } = useQuery({
    queryKey: ['/api/trades'],
    enabled: !!userId,
  });

  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    
    if (diffHours < 1) {
      const diffMins = Math.floor(diffMs / (1000 * 60));
      return `${diffMins}m ago`;
    } else if (diffHours < 24) {
      return `${diffHours}h ago`;
    } else {
      return date.toLocaleDateString();
    }
  };

  return (
    <Card className="border border-gray-200 shadow-sm">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold">Recent Trades</CardTitle>
          <Button variant="ghost" size="sm">
            <ExternalLink className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>
      
      <CardContent>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-3 text-sm font-medium text-gray-600">Symbol</th>
                <th className="text-left py-3 text-sm font-medium text-gray-600">Type</th>
                <th className="text-left py-3 text-sm font-medium text-gray-600">Price</th>
                <th className="text-left py-3 text-sm font-medium text-gray-600">P&L</th>
                <th className="text-left py-3 text-sm font-medium text-gray-600">Time</th>
              </tr>
            </thead>
            <tbody>
              {isLoading ? (
                // Loading skeleton
                Array.from({ length: 4 }).map((_, index) => (
                  <tr key={index} className="border-b border-gray-100">
                    <td className="py-3"><Skeleton className="h-4 w-16" /></td>
                    <td className="py-3"><Skeleton className="h-6 w-12" /></td>
                    <td className="py-3"><Skeleton className="h-4 w-20" /></td>
                    <td className="py-3"><Skeleton className="h-4 w-16" /></td>
                    <td className="py-3"><Skeleton className="h-4 w-12" /></td>
                  </tr>
                ))
              ) : trades && trades.length > 0 ? (
                trades.slice(0, 10).map((trade: any) => (
                  <tr key={trade.id} className="border-b border-gray-100">
                    <td className="py-3 text-sm font-medium text-gray-900">{trade.symbol}</td>
                    <td className="py-3">
                      <Badge 
                        variant={trade.type === 'BUY' ? 'default' : 'secondary'}
                        className={trade.type === 'BUY' 
                          ? 'bg-green-100 text-green-800 hover:bg-green-100' 
                          : 'bg-red-100 text-red-800 hover:bg-red-100'
                        }
                      >
                        {trade.type}
                      </Badge>
                    </td>
                    <td className="py-3 text-sm text-gray-900">
                      ₹{parseFloat(trade.entryPrice).toFixed(2)}
                    </td>
                    <td className="py-3 text-sm font-medium">
                      {trade.pnl ? (
                        <span className={parseFloat(trade.pnl) >= 0 ? 'text-green-600' : 'text-red-600'}>
                          {parseFloat(trade.pnl) >= 0 ? '+' : ''}₹{Math.abs(parseFloat(trade.pnl)).toFixed(0)}
                        </span>
                      ) : (
                        <span className="text-gray-500">-</span>
                      )}
                    </td>
                    <td className="py-3 text-sm text-gray-600">
                      {formatTime(trade.entryTime)}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={5} className="py-8 text-center text-gray-500">
                    No trades found. Start backtesting or live trading to see trades here.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
}
