import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { 
  BarChart3, 
  Settings, 
  History, 
  Play, 
  List, 
  TrendingUp, 
  LogOut,
  CheckCircle
} from "lucide-react";
import { cn } from "@/lib/utils";

interface SidebarProps {
  user?: {
    id: number;
    username: string;
    isAuthenticated: boolean;
  };
}

const navigation = [
  { name: "Dashboard", href: "/", icon: BarChart3 },
  { name: "Strategy Config", href: "/strategy", icon: Settings },
  { name: "Backtest Results", href: "/backtest", icon: History },
  { name: "Live Trading", href: "/live", icon: Play },
  { name: "Trade History", href: "/trades", icon: List },
  { name: "Analytics", href: "/analytics", icon: TrendingUp },
];

export default function Sidebar({ user }: SidebarProps) {
  const [location] = useLocation();

  return (
    <div className="w-64 bg-white border-r border-gray-200 flex flex-col">
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
            <BarChart3 className="text-white h-6 w-6" />
          </div>
          <div>
            <h1 className="text-lg font-semibold text-gray-900">Strategy Tester</h1>
            <p className="text-sm text-gray-600">Angel One SmartAPI</p>
          </div>
        </div>
      </div>
      
      {user && (
        <div className="p-4 border-b border-gray-200">
          <div className="flex items-center space-x-3 p-3 bg-green-50 rounded-lg">
            <CheckCircle className="w-4 h-4 text-green-600" />
            <div className="flex-1">
              <p className="text-sm font-medium text-gray-900">{user.username}</p>
              <p className="text-xs text-gray-600">
                {user.isAuthenticated ? "Connected to Angel One" : "Not connected"}
              </p>
            </div>
          </div>
        </div>
      )}
      
      <nav className="flex-1 p-4">
        <ul className="space-y-2">
          {navigation.map((item) => {
            const isActive = location === item.href;
            return (
              <li key={item.name}>
                <Link href={item.href}>
                  <Button
                    variant={isActive ? "default" : "ghost"}
                    className={cn(
                      "w-full justify-start",
                      isActive 
                        ? "bg-blue-600 text-white hover:bg-blue-700" 
                        : "text-gray-600 hover:bg-gray-100"
                    )}
                  >
                    <item.icon className="mr-3 h-4 w-4" />
                    {item.name}
                  </Button>
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
      
      <div className="p-4 border-t border-gray-200">
        <Button 
          variant="ghost" 
          className="w-full justify-start text-gray-600 hover:bg-gray-100"
        >
          <LogOut className="mr-3 h-4 w-4" />
          Logout
        </Button>
      </div>
    </div>
  );
}
