import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { BarChart3, Maximize2 } from "lucide-react";

interface MarketData {
  symbol: string;
  price: number;
  change: number;
  timestamp: number;
}

interface PriceChartProps {
  marketData?: MarketData;
}

export default function PriceChart({ marketData }: PriceChartProps) {
  const timeframes = ['5M', '15M', '1H', '1D'];
  const currentSymbol = marketData?.symbol || 'RELIANCE';
  const currentPrice = marketData?.price || 2485.30;
  const currentChange = marketData?.change || 1.25;

  return (
    <Card className="border border-gray-200 shadow-sm">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-lg font-semibold">Price Chart</CardTitle>
            <p className="text-sm text-gray-600">
              {currentSymbol} - ₹{currentPrice.toFixed(2)} 
              <span className={`ml-1 ${currentChange >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                ({currentChange >= 0 ? '+' : ''}{currentChange.toFixed(2)}%)
              </span>
            </p>
          </div>
          
          <div className="flex items-center space-x-2">
            {timeframes.map((timeframe, index) => (
              <Button
                key={timeframe}
                variant={index === 0 ? "default" : "outline"}
                size="sm"
              >
                {timeframe}
              </Button>
            ))}
          </div>
        </div>
      </CardHeader>
      
      <CardContent>
        {/* Chart placeholder - in production, integrate TradingView widget or Chart.js */}
        <div className="h-80 bg-gray-50 rounded-lg flex items-center justify-center border-2 border-dashed border-gray-300">
          <div className="text-center">
            <BarChart3 className="text-4xl text-gray-400 mb-4 mx-auto h-12 w-12" />
            <p className="text-gray-600 font-medium">TradingView Chart Component</p>
            <p className="text-sm text-gray-500 mt-1">
              Real-time OHLC candlestick chart with indicators
            </p>
          </div>
        </div>
        
        <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-200">
          <div className="flex items-center space-x-4 text-sm">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
              <span className="text-gray-600">EMA 20</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-red-500 rounded-full"></div>
              <span className="text-gray-600">EMA 50</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-green-500 rounded-full"></div>
              <span className="text-gray-600">Buy Signals</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-red-600 rounded-full"></div>
              <span className="text-gray-600">Sell Signals</span>
            </div>
          </div>
          
          <Button variant="ghost" size="sm">
            <Maximize2 className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
