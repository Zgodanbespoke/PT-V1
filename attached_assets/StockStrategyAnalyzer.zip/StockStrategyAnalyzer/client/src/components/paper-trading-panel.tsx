import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { TrendingUp, TrendingDown, Target, Shield, DollarSign } from "lucide-react";

interface PaperTradingPanelProps {
  userId: number;
  marketData?: {
    symbol: string;
    price: number;
    change: number;
    timestamp: number;
  };
}

interface OrderFormData {
  exchange: string;
  symbol: string;
  orderType: 'LIMIT' | 'MARKET';
  side: 'BUY' | 'SELL';
  quantity: number;
  limitPrice: number;
  takeProfitType: 'PERCENTAGE' | 'ABSOLUTE';
  takeProfitValue: number;
  stopLossType: 'PERCENTAGE' | 'ABSOLUTE';
  stopLossValue: number;
}

const NSE_SYMBOLS = [
  'RELIANCE', 'TCS', 'HDFC', 'INFY', 'ICICIBANK', 'HDFCBANK', 'ITC', 'SBIN',
  'BHARTIARTL', 'KOTAKBANK', 'LT', 'ASIANPAINT', 'AXISBANK', 'MARUTI', 'SUNPHARMA'
];

const BSE_SYMBOLS = [
  'SENSEX', 'BANKEX', 'MIDCAP', 'SMLCAP', 'REALTY', 'POWER', 'OIL&GAS', 'METAL'
];

export default function PaperTradingPanel({ userId, marketData }: PaperTradingPanelProps) {
  const { toast } = useToast();
  const [isPlacingOrder, setIsPlacingOrder] = useState(false);
  const [currentPrice, setCurrentPrice] = useState<number>(0);
  const [realTimePrice, setRealTimePrice] = useState<number>(0);
  
  const [orderForm, setOrderForm] = useState<OrderFormData>({
    exchange: 'NSE',
    symbol: 'RELIANCE',
    orderType: 'LIMIT',
    side: 'BUY',
    quantity: 1,
    limitPrice: 0,
    takeProfitType: 'PERCENTAGE',
    takeProfitValue: 5,
    stopLossType: 'PERCENTAGE',
    stopLossValue: 3
  });

  // Update current price when market data changes
  useEffect(() => {
    if (marketData && marketData.symbol === orderForm.symbol) {
      setCurrentPrice(marketData.price);
      setRealTimePrice(marketData.price);
      if (orderForm.limitPrice === 0) {
        setOrderForm(prev => ({ ...prev, limitPrice: marketData.price }));
      }
    }
  }, [marketData, orderForm.symbol]);

  const handleInputChange = (field: keyof OrderFormData, value: any) => {
    setOrderForm(prev => ({ ...prev, [field]: value }));
  };

  const calculateTakeProfit = () => {
    if (orderForm.takeProfitType === 'PERCENTAGE') {
      const multiplier = orderForm.side === 'BUY' ? 1 : -1;
      return orderForm.limitPrice * (1 + (orderForm.takeProfitValue / 100) * multiplier);
    } else {
      const multiplier = orderForm.side === 'BUY' ? 1 : -1;
      return orderForm.limitPrice + (orderForm.takeProfitValue * multiplier);
    }
  };

  const calculateStopLoss = () => {
    if (orderForm.stopLossType === 'PERCENTAGE') {
      const multiplier = orderForm.side === 'BUY' ? -1 : 1;
      return orderForm.limitPrice * (1 + (orderForm.stopLossValue / 100) * multiplier);
    } else {
      const multiplier = orderForm.side === 'BUY' ? -1 : 1;
      return orderForm.limitPrice + (orderForm.stopLossValue * multiplier);
    }
  };

  const placeOrder = async () => {
    setIsPlacingOrder(true);
    
    try {
      if (orderForm.orderType === 'MARKET') {
        // Execute market order immediately
        const response = await apiRequest('POST', '/api/trades', {
          symbol: orderForm.symbol,
          type: orderForm.side,
          quantity: orderForm.quantity,
          entryPrice: realTimePrice.toString(),
          tradeMode: 'PAPER',
          metadata: {
            orderType: 'MARKET',
            exchange: orderForm.exchange,
            takeProfit: {
              type: orderForm.takeProfitType,
              value: orderForm.takeProfitValue,
              targetPrice: calculateTakeProfit()
            },
            stopLoss: {
              type: orderForm.stopLossType,
              value: orderForm.stopLossValue,
              targetPrice: calculateStopLoss()
            }
          }
        }, { 'x-user-id': userId.toString() });

        toast({
          title: "Market Order Executed",
          description: `${orderForm.quantity} ${orderForm.symbol} at ₹${realTimePrice.toFixed(2)}`,
        });
      } else {
        // Place limit order for execution when price conditions are met
        const response = await apiRequest('POST', '/api/orders/limit', {
          symbol: orderForm.symbol,
          exchange: orderForm.exchange,
          side: orderForm.side,
          quantity: orderForm.quantity,
          limitPrice: orderForm.limitPrice,
          takeProfitPrice: calculateTakeProfit(),
          stopLossPrice: calculateStopLoss(),
          metadata: {
            takeProfitType: orderForm.takeProfitType,
            takeProfitValue: orderForm.takeProfitValue,
            stopLossType: orderForm.stopLossType,
            stopLossValue: orderForm.stopLossValue
          }
        }, { 'x-user-id': userId.toString() });

        const result = await response.json();
        
        toast({
          title: "Limit Order Placed",
          description: `Order #${result.orderId} - ${orderForm.quantity} ${orderForm.symbol} at ₹${orderForm.limitPrice.toFixed(2)}`,
        });
      }

      // Reset form
      setOrderForm(prev => ({ 
        ...prev, 
        quantity: 1, 
        limitPrice: realTimePrice,
        takeProfitValue: 5,
        stopLossValue: 3
      }));
      
    } catch (error: any) {
      toast({
        title: "Order Failed",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsPlacingOrder(false);
    }
  };

  const symbolsList = orderForm.exchange === 'NSE' ? NSE_SYMBOLS : BSE_SYMBOLS;

  return (
    <Card className="border border-gray-200 shadow-sm">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold">Paper Trading</CardTitle>
          <Badge className="bg-blue-100 text-blue-800">
            Real-time Prices
          </Badge>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {/* Exchange & Symbol Selection */}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label htmlFor="exchange">Exchange</Label>
            <Select value={orderForm.exchange} onValueChange={(value) => handleInputChange('exchange', value)}>
              <SelectTrigger className="mt-1">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="NSE">NSE</SelectItem>
                <SelectItem value="BSE">BSE</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <Label htmlFor="symbol">Symbol</Label>
            <Select value={orderForm.symbol} onValueChange={(value) => handleInputChange('symbol', value)}>
              <SelectTrigger className="mt-1">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {symbolsList.map((symbol) => (
                  <SelectItem key={symbol} value={symbol}>{symbol}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Current Price Display */}
        {realTimePrice > 0 && (
          <div className="p-3 bg-gray-50 rounded-lg">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Current Price</span>
              <div className="text-right">
                <span className="text-lg font-semibold">₹{realTimePrice.toFixed(2)}</span>
                {marketData && (
                  <span className={`ml-2 text-sm ${marketData.change >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    {marketData.change >= 0 ? '+' : ''}{marketData.change.toFixed(2)}%
                  </span>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Order Type & Side */}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label htmlFor="orderType">Order Type</Label>
            <Select value={orderForm.orderType} onValueChange={(value) => handleInputChange('orderType', value)}>
              <SelectTrigger className="mt-1">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="MARKET">Market</SelectItem>
                <SelectItem value="LIMIT">Limit</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <Label htmlFor="side">Side</Label>
            <Select value={orderForm.side} onValueChange={(value) => handleInputChange('side', value)}>
              <SelectTrigger className="mt-1">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="BUY">Buy</SelectItem>
                <SelectItem value="SELL">Sell</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Quantity & Limit Price */}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label htmlFor="quantity">Quantity</Label>
            <Input
              id="quantity"
              type="number"
              value={orderForm.quantity}
              onChange={(e) => handleInputChange('quantity', parseInt(e.target.value))}
              min="1"
              className="mt-1"
            />
          </div>
          
          {orderForm.orderType === 'LIMIT' && (
            <div>
              <Label htmlFor="limitPrice">Limit Price</Label>
              <Input
                id="limitPrice"
                type="number"
                value={orderForm.limitPrice}
                onChange={(e) => handleInputChange('limitPrice', parseFloat(e.target.value))}
                step="0.01"
                className="mt-1"
              />
            </div>
          )}
        </div>

        {/* Take Profit */}
        <div>
          <Label className="flex items-center space-x-2 mb-2">
            <Target className="h-4 w-4 text-green-600" />
            <span>Take Profit</span>
          </Label>
          <div className="grid grid-cols-3 gap-2">
            <Select value={orderForm.takeProfitType} onValueChange={(value) => handleInputChange('takeProfitType', value)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="PERCENTAGE">%</SelectItem>
                <SelectItem value="ABSOLUTE">₹</SelectItem>
              </SelectContent>
            </Select>
            <Input
              type="number"
              value={orderForm.takeProfitValue}
              onChange={(e) => handleInputChange('takeProfitValue', parseFloat(e.target.value))}
              step="0.01"
              min="0"
            />
            <div className="flex items-center px-3 bg-green-50 rounded border text-sm text-green-700">
              ₹{calculateTakeProfit().toFixed(2)}
            </div>
          </div>
        </div>

        {/* Stop Loss */}
        <div>
          <Label className="flex items-center space-x-2 mb-2">
            <Shield className="h-4 w-4 text-red-600" />
            <span>Stop Loss</span>
          </Label>
          <div className="grid grid-cols-3 gap-2">
            <Select value={orderForm.stopLossType} onValueChange={(value) => handleInputChange('stopLossType', value)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="PERCENTAGE">%</SelectItem>
                <SelectItem value="ABSOLUTE">₹</SelectItem>
              </SelectContent>
            </Select>
            <Input
              type="number"
              value={orderForm.stopLossValue}
              onChange={(e) => handleInputChange('stopLossValue', parseFloat(e.target.value))}
              step="0.01"
              min="0"
            />
            <div className="flex items-center px-3 bg-red-50 rounded border text-sm text-red-700">
              ₹{calculateStopLoss().toFixed(2)}
            </div>
          </div>
        </div>

        {/* Order Summary */}
        <div className="p-3 bg-blue-50 rounded-lg space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span>Order Value:</span>
            <span className="font-medium">
              ₹{(orderForm.quantity * (orderForm.orderType === 'MARKET' ? realTimePrice : orderForm.limitPrice)).toLocaleString('en-IN')}
            </span>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span>Risk/Reward:</span>
            <span className="font-medium text-green-600">
              1:{((Math.abs(calculateTakeProfit() - orderForm.limitPrice)) / Math.abs(calculateStopLoss() - orderForm.limitPrice)).toFixed(2)}
            </span>
          </div>
        </div>

        {/* Place Order Button */}
        <Button 
          onClick={placeOrder}
          disabled={isPlacingOrder || orderForm.quantity < 1}
          className={`w-full ${orderForm.side === 'BUY' ? 'bg-green-600 hover:bg-green-700' : 'bg-red-600 hover:bg-red-700'}`}
        >
          {isPlacingOrder ? (
            <>
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
              Placing Order...
            </>
          ) : (
            <>
              {orderForm.side === 'BUY' ? <TrendingUp className="mr-2 h-4 w-4" /> : <TrendingDown className="mr-2 h-4 w-4" />}
              {orderForm.side} {orderForm.quantity} {orderForm.symbol}
            </>
          )}
        </Button>
      </CardContent>
    </Card>
  );
}