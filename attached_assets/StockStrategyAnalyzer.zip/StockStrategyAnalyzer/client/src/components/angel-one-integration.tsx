import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Key, ExternalLink, CheckCircle, AlertCircle } from "lucide-react";

interface AngelOneIntegrationProps {
  userId: number;
  isAuthenticated?: boolean;
  onAuthSuccess: () => void;
}

export default function AngelOneIntegration({ userId, isAuthenticated, onAuthSuccess }: AngelOneIntegrationProps) {
  const { toast } = useToast();
  const [isConnecting, setIsConnecting] = useState(false);
  const [credentials, setCredentials] = useState({
    clientId: "R12345",
    apiKey: "bliQtYGE",
    secret: "82f59a66-09e6-4a65-9d1d-8fc2a10a6041",
    redirectUrl: window.location.origin + "/auth/callback"
  });

  const handleInputChange = (field: keyof typeof credentials, value: string) => {
    setCredentials(prev => ({ ...prev, [field]: value }));
  };

  const connectToAngelOne = async () => {
    setIsConnecting(true);
    
    try {
      const response = await apiRequest('POST', '/api/auth/angel-one', {
        clientId: credentials.clientId,
        apiKey: credentials.apiKey,
        secret: credentials.secret,
        userId
      });

      const result = await response.json();
      
      toast({
        title: "Angel One Connected",
        description: "Successfully connected to Angel One SmartAPI for real-time data",
      });

      onAuthSuccess();
      
    } catch (error: any) {
      toast({
        title: "Connection Failed",
        description: error.message || "Failed to connect to Angel One API",
        variant: "destructive",
      });
    } finally {
      setIsConnecting(false);
    }
  };

  if (isAuthenticated) {
    return (
      <Card className="border border-green-200 bg-green-50">
        <CardContent className="p-4">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
              <CheckCircle className="text-green-600 h-5 w-5" />
            </div>
            <div className="flex-1">
              <p className="font-medium text-green-900">Angel One Connected</p>
              <p className="text-sm text-green-700">Real-time market data is active</p>
            </div>
            <Badge className="bg-green-100 text-green-800">
              <div className="w-2 h-2 bg-green-600 rounded-full animate-pulse mr-2" />
              Live
            </Badge>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border border-gray-200 shadow-sm">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold">Angel One SmartAPI</CardTitle>
          <Key className="h-5 w-5 text-blue-600" />
        </div>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <Alert>
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            <div className="space-y-2">
              <p className="font-medium">Setup Instructions:</p>
              <ol className="text-sm space-y-1 ml-4 list-decimal">
                <li>Visit <a href="https://smartapi.angelbroking.com" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline inline-flex items-center">Angel One SmartAPI <ExternalLink className="h-3 w-3 ml-1" /></a></li>
                <li>Create an app and get your credentials</li>
                <li>Use this redirect URL: <code className="bg-gray-100 px-1 rounded text-xs">{credentials.redirectUrl}</code></li>
                <li>Enter your credentials below</li>
              </ol>
            </div>
          </AlertDescription>
        </Alert>

        <div className="space-y-3">
          <div>
            <Label htmlFor="clientId">Client ID</Label>
            <Input
              id="clientId"
              value={credentials.clientId}
              onChange={(e) => handleInputChange('clientId', e.target.value)}
              placeholder="Your Angel One Client ID"
              className="mt-1"
            />
          </div>
          
          <div>
            <Label htmlFor="apiKey">API Key</Label>
            <Input
              id="apiKey"
              type="password"
              value={credentials.apiKey}
              onChange={(e) => handleInputChange('apiKey', e.target.value)}
              placeholder="Your API Key"
              className="mt-1"
            />
          </div>
          
          <div>
            <Label htmlFor="secret">Secret Key</Label>
            <Input
              id="secret"
              type="password"
              value={credentials.secret}
              onChange={(e) => handleInputChange('secret', e.target.value)}
              placeholder="Your Secret Key"
              className="mt-1"
            />
          </div>
          
          <div>
            <Label htmlFor="redirectUrl">Redirect URL</Label>
            <Input
              id="redirectUrl"
              value={credentials.redirectUrl}
              onChange={(e) => handleInputChange('redirectUrl', e.target.value)}
              className="mt-1"
              readOnly
            />
            <p className="text-xs text-gray-600 mt-1">
              Use this URL in your Angel One app configuration
            </p>
          </div>
        </div>

        <Button 
          onClick={connectToAngelOne}
          disabled={isConnecting || !credentials.clientId || !credentials.apiKey || !credentials.secret}
          className="w-full"
        >
          {isConnecting ? (
            <>
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
              Connecting...
            </>
          ) : (
            <>
              <Key className="mr-2 h-4 w-4" />
              Connect to Angel One
            </>
          )}
        </Button>
      </CardContent>
    </Card>
  );
}