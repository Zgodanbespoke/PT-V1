import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useQuery } from "@tanstack/react-query";
import { Play, ArrowUp, ArrowDown } from "lucide-react";

interface LiveTradingStatusProps {
  userId: number;
  analytics?: {
    activeStrategies: number;
    openPositions: number;
    totalTrades: number;
    winRate: number;
  };
}

export default function LiveTradingStatus({ userId, analytics }: LiveTradingStatusProps) {
  const { data: trades, isLoading } = useQuery({
    queryKey: ['/api/trades'],
    enabled: !!userId,
  });

  // Get open positions
  const openPositions = trades?.filter((trade: any) => trade.status === 'OPEN') || [];
  const todayTrades = trades?.filter((trade: any) => {
    const tradeDate = new Date(trade.entryTime);
    const today = new Date();
    return tradeDate.toDateString() === today.toDateString();
  }) || [];

  return (
    <Card className="border border-gray-200 shadow-sm">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold">Live Trading Status</CardTitle>
          <Badge className="bg-green-100 text-green-800 hover:bg-green-100">
            <div className="w-2 h-2 bg-green-600 rounded-full animate-pulse mr-2" />
            Active
          </Badge>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg">
          <div>
            <p className="font-medium text-gray-900">Paper Trading Mode</p>
            <p className="text-sm text-gray-600">All trades are simulated</p>
          </div>
          <Play className="text-blue-600 h-8 w-8" />
        </div>
        
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-600">Active Strategies</span>
            <span className="text-sm font-medium text-gray-900">
              {analytics?.activeStrategies || 0}
            </span>
          </div>
          
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-600">Open Positions</span>
            <span className="text-sm font-medium text-gray-900">
              {openPositions.length}
            </span>
          </div>
          
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-600">Today's Trades</span>
            <span className="text-sm font-medium text-gray-900">
              {todayTrades.length}
            </span>
          </div>
          
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-600">Success Rate</span>
            <span className="text-sm font-medium text-green-600">
              {analytics?.winRate?.toFixed(1) || 0}%
            </span>
          </div>
        </div>
        
        <div className="pt-4 border-t border-gray-200">
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm font-medium text-gray-900">Active Positions</span>
            <Button variant="ghost" size="sm" className="text-blue-600 hover:text-blue-700">
              View All
            </Button>
          </div>
          
          {isLoading ? (
            <div className="space-y-2">
              {Array.from({ length: 2 }).map((_, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <Skeleton className="w-8 h-8 rounded-full" />
                    <div>
                      <Skeleton className="h-4 w-16 mb-1" />
                      <Skeleton className="h-3 w-20" />
                    </div>
                  </div>
                  <div className="text-right">
                    <Skeleton className="h-4 w-12 mb-1" />
                    <Skeleton className="h-3 w-8" />
                  </div>
                </div>
              ))}
            </div>
          ) : openPositions.length > 0 ? (
            <div className="space-y-2">
              {openPositions.slice(0, 3).map((position: any) => {
                const isLong = position.type === 'BUY';
                const mockPnl = Math.random() * 1000 - 500; // Mock P&L calculation
                const mockPnlPercent = (mockPnl / parseFloat(position.entryPrice)) * 100;
                
                return (
                  <div key={position.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                        isLong ? 'bg-green-100' : 'bg-red-100'
                      }`}>
                        {isLong ? (
                          <ArrowUp className="text-green-600 h-4 w-4" />
                        ) : (
                          <ArrowDown className="text-red-600 h-4 w-4" />
                        )}
                      </div>
                      <div>
                        <p className="text-sm font-medium text-gray-900">{position.symbol}</p>
                        <p className="text-xs text-gray-600">
                          {isLong ? 'Long' : 'Short'} • ₹{parseFloat(position.entryPrice).toFixed(0)}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className={`text-sm font-medium ${mockPnl >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {mockPnl >= 0 ? '+' : ''}{mockPnlPercent.toFixed(2)}%
                      </p>
                      <p className="text-xs text-gray-600">
                        {mockPnl >= 0 ? '+' : ''}₹{Math.abs(mockPnl).toFixed(0)}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="text-center py-4 text-gray-500 text-sm">
              No active positions
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
