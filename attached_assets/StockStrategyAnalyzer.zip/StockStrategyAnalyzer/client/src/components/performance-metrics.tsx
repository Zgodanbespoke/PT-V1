import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { TrendingUp, Percent, TrendingDown, List } from "lucide-react";

interface PerformanceMetricsProps {
  analytics?: {
    totalReturns: number;
    winRate: number;
    maxDrawdown: number;
    totalTrades: number;
  };
  isLoading?: boolean;
}

export default function PerformanceMetrics({ analytics, isLoading }: PerformanceMetricsProps) {
  const metrics = [
    {
      title: "Total Returns",
      value: analytics?.totalReturns || 0,
      prefix: "₹",
      suffix: "",
      change: "+12.5%",
      icon: TrendingUp,
      bgColor: "bg-green-100",
      iconColor: "text-green-600",
      changeColor: "text-green-600"
    },
    {
      title: "Win Rate",
      value: analytics?.winRate || 0,
      prefix: "",
      suffix: "%",
      change: "This Month",
      icon: Percent,
      bgColor: "bg-blue-100",
      iconColor: "text-blue-600",
      changeColor: "text-gray-600"
    },
    {
      title: "Max Drawdown",
      value: analytics?.maxDrawdown || 0,
      prefix: "₹",
      suffix: "",
      change: "-8.2%",
      icon: TrendingDown,
      bgColor: "bg-orange-100",
      iconColor: "text-orange-600",
      changeColor: "text-red-600"
    },
    {
      title: "Total Trades",
      value: analytics?.totalTrades || 0,
      prefix: "",
      suffix: "",
      change: "+3 Today",
      icon: List,
      bgColor: "bg-purple-100",
      iconColor: "text-purple-600",
      changeColor: "text-blue-600"
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
      {metrics.map((metric, index) => (
        <Card key={index} className="border border-gray-200 shadow-sm">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className={`w-12 h-12 ${metric.bgColor} rounded-lg flex items-center justify-center`}>
                <metric.icon className={`${metric.iconColor} h-6 w-6`} />
              </div>
              <span className={`text-sm font-medium ${metric.changeColor}`}>
                {metric.change}
              </span>
            </div>
            {isLoading ? (
              <div className="space-y-2">
                <Skeleton className="h-8 w-24" />
                <Skeleton className="h-4 w-16" />
              </div>
            ) : (
              <>
                <h3 className="text-2xl font-bold text-gray-900">
                  {metric.prefix}{metric.value.toLocaleString('en-IN')}{metric.suffix}
                </h3>
                <p className="text-gray-600 text-sm">{metric.title}</p>
              </>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
