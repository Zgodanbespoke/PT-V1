import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Settings, History, Play } from "lucide-react";

interface StrategyConfigProps {
  userId: number;
}

export default function StrategyConfig({ userId }: StrategyConfigProps) {
  const { toast } = useToast();
  const [isBacktesting, setIsBacktesting] = useState(false);
  const [isLiveTrading, setIsLiveTrading] = useState(false);
  
  const [config, setConfig] = useState({
    strategyType: "EMA_CROSSOVER",
    symbol: "RELIANCE",
    timeframe: "5min",
    capital: 100000,
    emaShort: 20,
    emaLong: 50,
  });

  const handleInputChange = (name: string, value: string | number) => {
    setConfig(prev => ({ ...prev, [name]: value }));
  };

  const runBacktest = async () => {
    setIsBacktesting(true);
    
    try {
      // First create strategy
      const strategyResponse = await apiRequest('POST', '/api/strategies', {
        name: `${config.strategyType} - ${config.symbol}`,
        type: config.strategyType,
        symbol: config.symbol,
        timeframe: config.timeframe,
        capital: config.capital.toString(),
        parameters: {
          emaShort: config.emaShort,
          emaLong: config.emaLong
        }
      });
      
      const strategy = await strategyResponse.json();
      
      // Run backtest
      const backtestResponse = await apiRequest('POST', '/api/backtest', {
        strategyId: strategy.id,
        symbol: config.symbol,
        startDate: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(), // 30 days ago
        endDate: new Date().toISOString()
      });
      
      const backtest = await backtestResponse.json();
      
      toast({
        title: "Backtest Complete",
        description: `Win Rate: ${backtest.winRate}% | Total Returns: ${backtest.totalReturns}%`,
      });
      
      // Invalidate analytics to refresh dashboard
      await queryClient.invalidateQueries({ queryKey: ['/api/analytics/dashboard'] });
      
    } catch (error: any) {
      toast({
        title: "Backtest Failed",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsBacktesting(false);
    }
  };

  const startLiveTrading = async () => {
    setIsLiveTrading(true);
    
    try {
      // Create and activate strategy
      const strategyResponse = await apiRequest('POST', '/api/strategies', {
        name: `LIVE - ${config.strategyType} - ${config.symbol}`,
        type: config.strategyType,
        symbol: config.symbol,
        timeframe: config.timeframe,
        capital: config.capital.toString(),
        parameters: {
          emaShort: config.emaShort,
          emaLong: config.emaLong
        }
      });
      
      const strategy = await strategyResponse.json();
      
      // Activate strategy for live trading
      await apiRequest('PUT', `/api/strategies/${strategy.id}`, {
        isActive: true
      });
      
      toast({
        title: "Live Trading Started",
        description: "Paper trading mode activated",
      });
      
    } catch (error: any) {
      toast({
        title: "Failed to Start Live Trading",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsLiveTrading(false);
    }
  };

  return (
    <Card className="border border-gray-200 shadow-sm">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold">Strategy Configuration</CardTitle>
          <Settings className="h-5 w-5 text-blue-600" />
        </div>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <div>
          <Label htmlFor="strategyType">Strategy Type</Label>
          <Select value={config.strategyType} onValueChange={(value) => handleInputChange('strategyType', value)}>
            <SelectTrigger className="mt-1">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="EMA_CROSSOVER">EMA Crossover</SelectItem>
              <SelectItem value="RSI_MEAN_REVERSION">RSI Mean Reversion</SelectItem>
              <SelectItem value="MACD_MOMENTUM">MACD Momentum</SelectItem>
              <SelectItem value="CUSTOM">Custom Strategy</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div>
          <Label htmlFor="symbol">Symbol</Label>
          <Input
            id="symbol"
            value={config.symbol}
            onChange={(e) => handleInputChange('symbol', e.target.value)}
            className="mt-1"
          />
        </div>
        
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label htmlFor="timeframe">Timeframe</Label>
            <Select value={config.timeframe} onValueChange={(value) => handleInputChange('timeframe', value)}>
              <SelectTrigger className="mt-1">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1min">1min</SelectItem>
                <SelectItem value="5min">5min</SelectItem>
                <SelectItem value="15min">15min</SelectItem>
                <SelectItem value="1hr">1hr</SelectItem>
                <SelectItem value="1day">1day</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <Label htmlFor="capital">Capital</Label>
            <Input
              id="capital"
              type="number"
              value={config.capital}
              onChange={(e) => handleInputChange('capital', parseInt(e.target.value))}
              className="mt-1"
            />
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label htmlFor="emaShort">EMA Short</Label>
            <Input
              id="emaShort"
              type="number"
              value={config.emaShort}
              onChange={(e) => handleInputChange('emaShort', parseInt(e.target.value))}
              className="mt-1"
            />
          </div>
          
          <div>
            <Label htmlFor="emaLong">EMA Long</Label>
            <Input
              id="emaLong"
              type="number"
              value={config.emaLong}
              onChange={(e) => handleInputChange('emaLong', parseInt(e.target.value))}
              className="mt-1"
            />
          </div>
        </div>
        
        <div className="flex space-x-3 pt-4">
          <Button 
            onClick={runBacktest}
            disabled={isBacktesting}
            className="flex-1"
          >
            {isBacktesting ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Running...
              </>
            ) : (
              <>
                <History className="mr-2 h-4 w-4" />
                Backtest
              </>
            )}
          </Button>
          
          <Button 
            onClick={startLiveTrading}
            disabled={isLiveTrading}
            variant="default"
            className="flex-1 bg-green-600 hover:bg-green-700"
          >
            {isLiveTrading ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Starting...
              </>
            ) : (
              <>
                <Play className="mr-2 h-4 w-4" />
                Live Test
              </>
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
