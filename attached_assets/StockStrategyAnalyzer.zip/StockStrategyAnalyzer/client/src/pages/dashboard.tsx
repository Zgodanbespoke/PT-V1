import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import Sidebar from "@/components/sidebar";
import Header from "@/components/header";
import PerformanceMetrics from "@/components/performance-metrics";
import StrategyConfig from "@/components/strategy-config";
import PriceChart from "@/components/price-chart";
import RecentTrades from "@/components/recent-trades";
import LiveTradingStatus from "@/components/live-trading-status";
import PaperTradingPanel from "@/components/paper-trading-panel";
import AngelOneIntegration from "@/components/angel-one-integration";
import { useWebSocket } from "@/hooks/use-websocket";

export default function Dashboard() {
  const [userId] = useState(1); // Mock user ID for demo
  const [showAuthModal, setShowAuthModal] = useState(false);
  
  // WebSocket connection for real-time data
  const { socket, isConnected, marketData } = useWebSocket();

  // Fetch user data
  const { data: user, isLoading: userLoading } = useQuery({
    queryKey: [`/api/user/${userId}`],
    enabled: !!userId,
  });

  // Fetch dashboard analytics with authentication header  
  const { data: analytics, isLoading: analyticsLoading } = useQuery({
    queryKey: ['/api/analytics/dashboard'],
    enabled: !!userId,
    refetchInterval: 30000,
    queryFn: async () => {
      const response = await fetch('/api/analytics/dashboard', {
        headers: { 'x-user-id': userId.toString() }
      });
      if (!response.ok) throw new Error('Failed to fetch analytics');
      return response.json();
    }
  });

  const handleAuthSuccess = () => {
    setShowAuthModal(false);
  };

  if (userLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-2 text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen overflow-hidden bg-gray-50">
      <Sidebar user={user} />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header 
          analytics={analytics} 
          isConnected={isConnected}
          isLoading={analyticsLoading}
        />
        
        <div className="flex-1 overflow-auto p-6">
          <PerformanceMetrics analytics={analytics} isLoading={analyticsLoading} />
          
          {/* Angel One Integration */}
          <div className="mb-6">
            <AngelOneIntegration 
              userId={userId}
              isAuthenticated={user?.isAuthenticated}
              onAuthSuccess={handleAuthSuccess}
            />
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
            <PaperTradingPanel userId={userId} marketData={marketData || undefined} />
            <div className="lg:col-span-2">
              <PriceChart marketData={marketData || undefined} />
            </div>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <RecentTrades userId={userId} />
            <LiveTradingStatus userId={userId} analytics={analytics} />
          </div>
        </div>
      </div>
    </div>
  );
}
