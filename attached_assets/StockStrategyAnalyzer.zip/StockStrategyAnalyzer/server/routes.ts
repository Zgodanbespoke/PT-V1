import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { angelOneService } from "./angel-one-service";
import { orderExecutionEngine } from "./order-execution-engine";
import { insertUserSchema, insertStrategySchema, insertTradeSchema, insertBacktestSchema } from "@shared/schema";
import { z } from "zod";

interface AuthenticatedRequest {
  userId?: number;
}

interface WebSocketMessage {
  type: string;
  payload: any;
}

interface MarketDataMessage {
  symbol: string;
  price: number;
  change: number;
  timestamp: number;
}

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // WebSocket server for real-time data
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  // Store connected clients
  const clients = new Set<WebSocket>();
  
  wss.on('connection', (ws: WebSocket) => {
    clients.add(ws);
    
    ws.on('message', (data: string) => {
      try {
        const message: WebSocketMessage = JSON.parse(data);
        handleWebSocketMessage(ws, message);
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    });
    
    ws.on('close', () => {
      clients.delete(ws);
    });
    
    // Send initial connection confirmation
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({
        type: 'connected',
        payload: { message: 'Connected to trading data stream' }
      }));
    }
  });

  // Broadcast market data to all connected clients
  function broadcastMarketData(data: MarketDataMessage) {
    const message = JSON.stringify({
      type: 'market_data',
      payload: data
    });
    
    clients.forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(message);
      }
    });
  }

  // Handle WebSocket messages
  function handleWebSocketMessage(ws: WebSocket, message: WebSocketMessage) {
    switch (message.type) {
      case 'subscribe':
        // Handle symbol subscription
        console.log('Client subscribed to:', message.payload.symbol);
        break;
      case 'unsubscribe':
        // Handle symbol unsubscription
        console.log('Client unsubscribed from:', message.payload.symbol);
        break;
      default:
        console.log('Unknown message type:', message.type);
    }
  }

  // Mock market data simulation (replace with real Angel One WebSocket)
  function startMarketDataSimulation() {
    const symbols = ['RELIANCE', 'HDFC', 'TCS', 'INFY', 'ICICIBANK'];
    
    setInterval(() => {
      symbols.forEach(symbol => {
        const basePrice = {
          'RELIANCE': 2485,
          'HDFC': 1658,
          'TCS': 3425,
          'INFY': 1789,
          'ICICIBANK': 1156
        }[symbol] || 1000;
        
        const change = (Math.random() - 0.5) * 0.02; // +/- 2% random change
        const price = basePrice * (1 + change);
        
        broadcastMarketData({
          symbol,
          price: Math.round(price * 100) / 100,
          change: Math.round(change * 10000) / 100, // percentage
          timestamp: Date.now()
        });
      });
    }, 5000); // Update every 5 seconds
  }

  // Start market data simulation
  startMarketDataSimulation();

  // Authentication middleware
  const requireAuth = (req: any, res: any, next: any) => {
    // For demo purposes, we'll use a simple user ID in header
    // In production, implement proper JWT or session authentication
    const userId = req.headers['x-user-id'];
    if (!userId) {
      return res.status(401).json({ message: 'Authentication required' });
    }
    req.userId = parseInt(userId);
    next();
  };

  // Angel One authentication endpoint
  app.post('/api/auth/angel-one', async (req, res) => {
    try {
      const { clientId, apiKey, secret, userId } = req.body;
      
      if (!clientId || !apiKey || !secret) {
        return res.status(400).json({ message: 'Missing required credentials' });
      }

      // Authenticate with real Angel One API
      const authSuccess = await angelOneService.authenticate({
        clientId,
        apiKey,
        secret
      });

      if (!authSuccess) {
        return res.status(401).json({ message: 'Angel One authentication failed' });
      }

      // Update user with Angel One credentials
      const user = await storage.updateUser(userId, {
        angelOneClientId: clientId,
        angelOneApiKey: apiKey,
        angelOneSecret: secret,
        isAuthenticated: true,
        sessionToken: `angel_one_${Date.now()}`
      });

      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }

      // Set up market data callback to broadcast to WebSocket clients
      angelOneService.onMarketDataUpdate = (marketData) => {
        broadcastMarketData({
          symbol: marketData.symbol,
          price: marketData.price,
          change: marketData.change,
          timestamp: marketData.timestamp
        });
      };

      res.json({ 
        message: 'Angel One authentication successful',
        user: {
          id: user.id,
          username: user.username,
          isAuthenticated: user.isAuthenticated
        }
      });
    } catch (error) {
      console.error('Angel One auth error:', error);
      res.status(500).json({ message: 'Authentication failed' });
    }
  });

  // User registration
  app.post('/api/auth/register', async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const user = await storage.createUser(userData);
      res.json({
        id: user.id,
        username: user.username,
        isAuthenticated: user.isAuthenticated
      });
    } catch (error) {
      res.status(400).json({ message: 'Registration failed', error });
    }
  });

  // Get user profile
  app.get('/api/user/:id', async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      let user = await storage.getUser(userId);
      
      // Create demo user if not found
      if (!user && userId === 1) {
        user = await storage.createUser({
          username: 'demo_trader',
          password: 'demo123'
        });
      }
      
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }

      res.json({
        id: user.id,
        username: user.username,
        isAuthenticated: user.isAuthenticated || false
      });
    } catch (error) {
      res.status(500).json({ message: 'Failed to get user' });
    }
  });

  // Strategy endpoints
  app.get('/api/strategies', requireAuth, async (req: any, res) => {
    try {
      const strategies = await storage.getStrategies(req.userId);
      res.json(strategies);
    } catch (error) {
      res.status(500).json({ message: 'Failed to get strategies' });
    }
  });

  app.post('/api/strategies', requireAuth, async (req: any, res) => {
    try {
      const strategyData = insertStrategySchema.parse({
        ...req.body,
        userId: req.userId
      });
      const strategy = await storage.createStrategy(strategyData);
      res.json(strategy);
    } catch (error) {
      res.status(400).json({ message: 'Failed to create strategy', error });
    }
  });

  app.put('/api/strategies/:id', requireAuth, async (req: any, res) => {
    try {
      const strategyId = parseInt(req.params.id);
      const updates = req.body;
      const strategy = await storage.updateStrategy(strategyId, updates);
      
      if (!strategy) {
        return res.status(404).json({ message: 'Strategy not found' });
      }
      
      res.json(strategy);
    } catch (error) {
      res.status(400).json({ message: 'Failed to update strategy' });
    }
  });

  // Backtest endpoint
  app.post('/api/backtest', requireAuth, async (req: any, res) => {
    try {
      const { strategyId, symbol, startDate, endDate } = req.body;
      
      // Mock backtest execution
      const mockResults = {
        totalTrades: Math.floor(Math.random() * 100) + 50,
        winRate: Math.round((Math.random() * 30 + 60) * 100) / 100, // 60-90%
        totalReturns: Math.round((Math.random() * 25 + 5) * 100) / 100, // 5-30%
        maxDrawdown: Math.round((Math.random() * 15 + 5) * 100) / 100, // 5-20%
        trades: []
      };

      const backtest = await storage.createBacktest({
        userId: req.userId,
        strategyId,
        symbol,
        startDate: new Date(startDate),
        endDate: new Date(endDate),
        totalTrades: mockResults.totalTrades,
        winRate: mockResults.winRate.toString(),
        totalReturns: mockResults.totalReturns.toString(),
        maxDrawdown: mockResults.maxDrawdown.toString(),
        results: mockResults
      });

      res.json(backtest);
    } catch (error) {
      res.status(400).json({ message: 'Backtest failed', error });
    }
  });

  // Trades endpoints
  app.get('/api/trades', requireAuth, async (req: any, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit) : undefined;
      const trades = await storage.getTrades(req.userId, limit);
      res.json(trades);
    } catch (error) {
      res.status(500).json({ message: 'Failed to get trades' });
    }
  });

  // Enhanced order placement endpoint for limit orders with TP/SL
  app.post('/api/orders/limit', requireAuth, async (req: any, res) => {
    try {
      const { 
        symbol, 
        exchange = 'NSE', 
        side, 
        quantity, 
        limitPrice, 
        takeProfitPrice, 
        stopLossPrice,
        metadata 
      } = req.body;

      if (!angelOneService.getAuthenticationStatus()) {
        return res.status(401).json({ message: 'Angel One authentication required' });
      }

      // Add limit order to execution engine
      const orderId = orderExecutionEngine.addLimitOrder({
        userId: req.userId,
        symbol,
        exchange,
        side,
        quantity: parseInt(quantity),
        limitPrice: parseFloat(limitPrice),
        takeProfitPrice: parseFloat(takeProfitPrice),
        stopLossPrice: parseFloat(stopLossPrice),
        metadata
      });

      res.json({ 
        orderId,
        message: `Limit order placed for ${quantity} ${symbol} at ₹${limitPrice}`,
        status: 'PENDING'
      });
    } catch (error) {
      console.error('Limit order error:', error);
      res.status(400).json({ message: 'Failed to place limit order', error });
    }
  });

  // Get pending orders
  app.get('/api/orders/pending', requireAuth, async (req: any, res) => {
    try {
      const pendingOrders = orderExecutionEngine.getPendingOrders(req.userId);
      res.json(pendingOrders);
    } catch (error) {
      res.status(500).json({ message: 'Failed to get pending orders' });
    }
  });

  // Cancel order
  app.delete('/api/orders/:orderId', requireAuth, async (req: any, res) => {
    try {
      const orderId = parseInt(req.params.orderId);
      const cancelled = orderExecutionEngine.cancelOrder(orderId);
      
      if (cancelled) {
        res.json({ message: 'Order cancelled successfully' });
      } else {
        res.status(404).json({ message: 'Order not found or already filled' });
      }
    } catch (error) {
      res.status(500).json({ message: 'Failed to cancel order' });
    }
  });

  app.post('/api/trades', requireAuth, async (req: any, res) => {
    try {
      const tradeData = insertTradeSchema.parse({
        ...req.body,
        userId: req.userId
      });
      const trade = await storage.createTrade(tradeData);
      
      // Broadcast trade to WebSocket clients
      const tradeMessage = JSON.stringify({
        type: 'trade_executed',
        payload: trade
      });
      
      clients.forEach(client => {
        if (client.readyState === WebSocket.OPEN) {
          client.send(tradeMessage);
        }
      });
      
      res.json(trade);
    } catch (error) {
      res.status(400).json({ message: 'Failed to create trade', error });
    }
  });

  // Real-time market data endpoint
  app.get('/api/market-data/:symbol', async (req, res) => {
    try {
      const { symbol } = req.params;
      const { exchange = 'NSE' } = req.query;
      
      if (angelOneService.getAuthenticationStatus()) {
        // Get live data from Angel One API
        const liveData = await angelOneService.getLivePrice(symbol, exchange as 'NSE' | 'BSE');
        res.json({
          symbol,
          price: liveData.price,
          change: liveData.change,
          volume: liveData.volume,
          timestamp: Date.now()
        });
      } else {
        res.status(401).json({ message: 'Angel One authentication required' });
      }
    } catch (error) {
      console.error('Market data fetch error:', error);
      res.status(500).json({ message: 'Failed to get market data' });
    }
  });

  // Subscribe to symbol endpoint
  app.post('/api/market-data/subscribe', async (req, res) => {
    try {
      const { symbol, exchange = 'NSE' } = req.body;
      
      if (!angelOneService.getAuthenticationStatus()) {
        return res.status(401).json({ message: 'Angel One authentication required' });
      }

      await angelOneService.subscribeToSymbol(symbol, exchange);
      res.json({ message: `Subscribed to ${symbol} on ${exchange}` });
    } catch (error) {
      console.error('Subscription error:', error);
      res.status(500).json({ message: 'Failed to subscribe to symbol' });
    }
  });

  // Historical data endpoint
  app.post('/api/market-data/historical', async (req, res) => {
    try {
      const { symbol, exchange = 'NSE', timeframe, fromDate, toDate } = req.body;
      
      if (!angelOneService.getAuthenticationStatus()) {
        return res.status(401).json({ message: 'Angel One authentication required' });
      }

      const historicalData = await angelOneService.getHistoricalData({
        symbol,
        exchange,
        timeframe,
        fromDate,
        toDate
      });

      res.json(historicalData);
    } catch (error) {
      console.error('Historical data error:', error);
      res.status(500).json({ message: 'Failed to get historical data' });
    }
  });

  // Dashboard analytics endpoint
  app.get('/api/analytics/dashboard', requireAuth, async (req: any, res) => {
    try {
      const trades = await storage.getTrades(req.userId);
      const strategies = await storage.getStrategies(req.userId);
      
      // Calculate analytics
      const totalTrades = trades.length;
      const closedTrades = trades.filter(t => t.status === 'CLOSED');
      const profitableTrades = closedTrades.filter(t => parseFloat(t.pnl || '0') > 0);
      const winRate = closedTrades.length > 0 ? (profitableTrades.length / closedTrades.length) * 100 : 0;
      const totalReturns = closedTrades.reduce((sum, t) => sum + parseFloat(t.pnl || '0'), 0);
      const activeStrategies = strategies.filter(s => s.isActive).length;
      const openPositions = trades.filter(t => t.status === 'OPEN').length;
      
      res.json({
        totalTrades,
        winRate: Math.round(winRate * 100) / 100,
        totalReturns: Math.round(totalReturns * 100) / 100,
        maxDrawdown: Math.round(Math.random() * 15 * 100) / 100, // Mock value
        activeStrategies,
        openPositions,
        portfolioValue: 125480 + totalReturns // Mock base + returns
      });
    } catch (error) {
      res.status(500).json({ message: 'Failed to get analytics' });
    }
  });

  return httpServer;
}
