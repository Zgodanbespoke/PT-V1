import { storage } from "./storage";
import { angelOneService } from "./angel-one-service";

interface PendingOrder {
  id: number;
  userId: number;
  symbol: string;
  exchange: 'NSE' | 'BSE';
  orderType: 'LIMIT' | 'MARKET';
  side: 'BUY' | 'SELL';
  quantity: number;
  limitPrice: number;
  takeProfitPrice: number;
  stopLossPrice: number;
  currentPrice: number;
  status: 'PENDING' | 'FILLED' | 'CANCELLED';
  createdAt: Date;
  metadata: any;
}

class OrderExecutionEngine {
  private pendingOrders: Map<number, PendingOrder> = new Map();
  private priceMonitorInterval: NodeJS.Timer | null = null;
  private currentOrderId = 1;

  constructor() {
    this.startPriceMonitoring();
  }

  addLimitOrder(orderData: {
    userId: number;
    symbol: string;
    exchange: 'NSE' | 'BSE';
    side: 'BUY' | 'SELL';
    quantity: number;
    limitPrice: number;
    takeProfitPrice: number;
    stopLossPrice: number;
    metadata: any;
  }): number {
    const orderId = this.currentOrderId++;
    
    const order: PendingOrder = {
      id: orderId,
      ...orderData,
      orderType: 'LIMIT',
      currentPrice: 0,
      status: 'PENDING',
      createdAt: new Date()
    };

    this.pendingOrders.set(orderId, order);
    console.log(`Added limit order ${orderId} for ${orderData.symbol} at ₹${orderData.limitPrice}`);
    
    return orderId;
  }

  cancelOrder(orderId: number): boolean {
    const order = this.pendingOrders.get(orderId);
    if (order && order.status === 'PENDING') {
      order.status = 'CANCELLED';
      this.pendingOrders.delete(orderId);
      console.log(`Cancelled order ${orderId}`);
      return true;
    }
    return false;
  }

  private async startPriceMonitoring(): Promise<void> {
    // Monitor prices every 2 seconds
    this.priceMonitorInterval = setInterval(async () => {
      await this.checkPendingOrders();
    }, 2000);
  }

  private async checkPendingOrders(): Promise<void> {
    if (!angelOneService.getAuthenticationStatus()) {
      return;
    }

    for (const [orderId, order] of this.pendingOrders) {
      if (order.status !== 'PENDING') continue;

      try {
        // Get current market price
        const livePrice = await angelOneService.getLivePrice(order.symbol, order.exchange);
        order.currentPrice = livePrice.price;

        // Check if limit order should be executed
        const shouldExecute = this.shouldExecuteLimitOrder(order, livePrice.price);
        
        if (shouldExecute) {
          await this.executeLimitOrder(order, livePrice.price);
        }

        // Check existing positions for take profit/stop loss
        await this.checkExistingPositions(order, livePrice.price);

      } catch (error) {
        console.error(`Error checking order ${orderId}:`, error);
      }
    }
  }

  private shouldExecuteLimitOrder(order: PendingOrder, currentPrice: number): boolean {
    if (order.side === 'BUY') {
      // Buy limit order executes when current price <= limit price
      return currentPrice <= order.limitPrice;
    } else {
      // Sell limit order executes when current price >= limit price
      return currentPrice >= order.limitPrice;
    }
  }

  private async executeLimitOrder(order: PendingOrder, executionPrice: number): Promise<void> {
    try {
      // Create trade record
      const trade = await storage.createTrade({
        userId: order.userId,
        symbol: order.symbol,
        type: order.side,
        quantity: order.quantity,
        entryPrice: executionPrice.toString(),
        tradeMode: 'PAPER',
        strategyId: null,
        metadata: {
          ...order.metadata,
          executionType: 'LIMIT_ORDER',
          originalLimitPrice: order.limitPrice,
          takeProfitPrice: order.takeProfitPrice,
          stopLossPrice: order.stopLossPrice,
          executedAt: new Date().toISOString()
        }
      });

      // Mark order as filled
      order.status = 'FILLED';
      this.pendingOrders.delete(order.id);

      console.log(`Executed limit order ${order.id}: ${order.side} ${order.quantity} ${order.symbol} at ₹${executionPrice}`);
      
      // Broadcast execution to WebSocket clients
      this.broadcastOrderExecution({
        orderId: order.id,
        tradeId: trade.id,
        symbol: order.symbol,
        side: order.side,
        quantity: order.quantity,
        price: executionPrice,
        type: 'LIMIT_ORDER_FILLED'
      });

    } catch (error) {
      console.error(`Failed to execute limit order ${order.id}:`, error);
    }
  }

  private async checkExistingPositions(order: PendingOrder, currentPrice: number): Promise<void> {
    try {
      // Get user's open trades for this symbol
      const userTrades = await storage.getTrades(order.userId);
      const openTrades = userTrades.filter(trade => 
        trade.status === 'OPEN' && 
        trade.symbol === order.symbol &&
        trade.metadata && 
        typeof trade.metadata === 'object' &&
        'takeProfitPrice' in trade.metadata
      );

      for (const trade of openTrades) {
        const metadata = trade.metadata as any;
        const entryPrice = parseFloat(trade.entryPrice);
        
        let shouldClose = false;
        let exitReason = '';

        // Check take profit
        if (trade.type === 'BUY' && currentPrice >= metadata.takeProfitPrice) {
          shouldClose = true;
          exitReason = 'TAKE_PROFIT';
        } else if (trade.type === 'SELL' && currentPrice <= metadata.takeProfitPrice) {
          shouldClose = true;
          exitReason = 'TAKE_PROFIT';
        }

        // Check stop loss
        if (trade.type === 'BUY' && currentPrice <= metadata.stopLossPrice) {
          shouldClose = true;
          exitReason = 'STOP_LOSS';
        } else if (trade.type === 'SELL' && currentPrice >= metadata.stopLossPrice) {
          shouldClose = true;
          exitReason = 'STOP_LOSS';
        }

        if (shouldClose) {
          await this.closePosition(trade, currentPrice, exitReason);
        }
      }
    } catch (error) {
      console.error('Error checking existing positions:', error);
    }
  }

  private async closePosition(trade: any, exitPrice: number, exitReason: string): Promise<void> {
    try {
      const entryPrice = parseFloat(trade.entryPrice);
      const pnl = trade.type === 'BUY' 
        ? (exitPrice - entryPrice) * trade.quantity
        : (entryPrice - exitPrice) * trade.quantity;

      // Update trade record
      await storage.updateTrade(trade.id, {
        status: 'CLOSED',
        exitPrice: exitPrice.toString(),
        pnl: pnl.toString(),
        exitTime: new Date(),
        metadata: {
          ...trade.metadata,
          exitReason,
          closedAt: new Date().toISOString()
        }
      });

      console.log(`Closed position: ${trade.symbol} - ${exitReason} - P&L: ₹${pnl.toFixed(2)}`);

      // Broadcast position closure
      this.broadcastOrderExecution({
        tradeId: trade.id,
        symbol: trade.symbol,
        side: trade.type === 'BUY' ? 'SELL' : 'BUY',
        quantity: trade.quantity,
        price: exitPrice,
        pnl: pnl,
        type: exitReason
      });

    } catch (error) {
      console.error(`Failed to close position ${trade.id}:`, error);
    }
  }

  private broadcastOrderExecution(data: any): void {
    // This would be connected to the WebSocket broadcast function
    console.log('Order execution broadcast:', data);
  }

  getPendingOrders(userId?: number): PendingOrder[] {
    const orders = Array.from(this.pendingOrders.values());
    return userId ? orders.filter(order => order.userId === userId) : orders;
  }

  getOrderStatus(orderId: number): PendingOrder | undefined {
    return this.pendingOrders.get(orderId);
  }

  stop(): void {
    if (this.priceMonitorInterval) {
      clearInterval(this.priceMonitorInterval);
      this.priceMonitorInterval = null;
    }
  }
}

export const orderExecutionEngine = new OrderExecutionEngine();