// Angel One SmartAPI Service for real market data integration
import { WebSocket as WSClient } from 'ws';

interface AngelOneCredentials {
  clientId: string;
  apiKey: string;
  secret: string;
  refreshToken?: string;
  accessToken?: string;
}

interface MarketDataSubscription {
  symbol: string;
  exchange: 'NSE' | 'BSE';
  token: string;
}

export class AngelOneService {
  private credentials: AngelOneCredentials | null = null;
  private wsConnection: WSClient | null = null;
  private isAuthenticated = false;
  private subscriptions: Map<string, MarketDataSubscription> = new Map();
  
  // Angel One API base URLs
  private readonly API_BASE = 'https://apiconnect.angelbroking.com';
  private readonly WS_BASE = 'wss://smartapisocket.angelone.in/smart-stream';

  async authenticate(credentials: AngelOneCredentials): Promise<boolean> {
    try {
      this.credentials = credentials;
      
      // Step 1: Generate session (login)
      const loginResponse = await fetch(`${this.API_BASE}/rest/auth/angelbroking/user/v1/loginByPassword`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'X-UserType': 'USER',
          'X-SourceID': 'WEB',
          'X-ClientLocalIP': '192.168.1.1',
          'X-ClientPublicIP': '106.193.147.98',
          'X-MACAddress': '00-15-5D-B8-B9-22',
          'X-PrivateKey': credentials.apiKey
        },
        body: JSON.stringify({
          clientcode: credentials.clientId,
          password: credentials.secret
        })
      });

      if (!loginResponse.ok) {
        throw new Error(`Angel One authentication failed: ${loginResponse.statusText}`);
      }

      const loginData = await loginResponse.json();
      
      if (loginData.status && loginData.data) {
        this.credentials.accessToken = loginData.data.jwtToken;
        this.credentials.refreshToken = loginData.data.refreshToken;
        this.isAuthenticated = true;
        
        console.log('Angel One authentication successful');
        
        // Initialize WebSocket connection for real-time data
        await this.initializeWebSocket();
        
        return true;
      } else {
        throw new Error(`Angel One authentication failed: ${loginData.message}`);
      }
    } catch (error) {
      console.error('Angel One authentication error:', error);
      this.isAuthenticated = false;
      return false;
    }
  }

  private async initializeWebSocket(): Promise<void> {
    if (!this.credentials?.accessToken) {
      throw new Error('No access token available for WebSocket connection');
    }

    try {
      this.wsConnection = new WSClient(this.WS_BASE, {
        headers: {
          'Authorization': `Bearer ${this.credentials.accessToken}`,
          'x-api-key': this.credentials.apiKey,
          'x-client-code': this.credentials.clientId
        }
      });

      this.wsConnection.on('open', () => {
        console.log('Angel One WebSocket connected');
      });

      this.wsConnection.on('message', (data) => {
        try {
          const message = JSON.parse(data.toString());
          this.handleWebSocketMessage(message);
        } catch (error) {
          console.error('Error parsing WebSocket message:', error);
        }
      });

      this.wsConnection.on('error', (error) => {
        console.error('Angel One WebSocket error:', error);
      });

      this.wsConnection.on('close', () => {
        console.log('Angel One WebSocket disconnected');
        // Attempt to reconnect after 5 seconds
        setTimeout(() => this.initializeWebSocket(), 5000);
      });

    } catch (error) {
      console.error('WebSocket initialization failed:', error);
    }
  }

  private handleWebSocketMessage(message: any): void {
    // Handle different types of market data messages
    if (message.ak === 'tk' && message.tk) {
      // Token price update
      const tokenData = message.tk;
      const subscription = Array.from(this.subscriptions.values())
        .find(sub => sub.token === tokenData.tk);
      
      if (subscription && this.onMarketDataUpdate) {
        this.onMarketDataUpdate({
          symbol: subscription.symbol,
          price: parseFloat(tokenData.lp || tokenData.c),
          change: parseFloat(tokenData.pc || 0),
          timestamp: Date.now(),
          volume: parseInt(tokenData.v || 0),
          high: parseFloat(tokenData.h || 0),
          low: parseFloat(tokenData.l || 0),
          open: parseFloat(tokenData.o || 0)
        });
      }
    }
  }

  public onMarketDataUpdate?: (data: {
    symbol: string;
    price: number;
    change: number;
    timestamp: number;
    volume: number;
    high: number;
    low: number;
    open: number;
  }) => void;

  async getHistoricalData(params: {
    symbol: string;
    exchange: 'NSE' | 'BSE';
    timeframe: string;
    fromDate: string;
    toDate: string;
  }): Promise<any[]> {
    if (!this.isAuthenticated || !this.credentials?.accessToken) {
      throw new Error('Not authenticated with Angel One');
    }

    try {
      const response = await fetch(`${this.API_BASE}/rest/secure/angelbroking/historical/v1/getCandleData`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.credentials.accessToken}`,
          'Accept': 'application/json',
          'X-UserType': 'USER',
          'X-SourceID': 'WEB',
          'X-ClientLocalIP': '192.168.1.1',
          'X-ClientPublicIP': '106.193.147.98',
          'X-MACAddress': '00-15-5D-B8-B9-22',
          'X-PrivateKey': this.credentials.apiKey
        },
        body: JSON.stringify({
          exchange: params.exchange,
          symboltoken: await this.getSymbolToken(params.symbol, params.exchange),
          interval: params.timeframe,
          fromdate: params.fromDate,
          todate: params.toDate
        })
      });

      if (!response.ok) {
        throw new Error(`Historical data fetch failed: ${response.statusText}`);
      }

      const data = await response.json();
      return data.data || [];
    } catch (error) {
      console.error('Error fetching historical data:', error);
      throw error;
    }
  }

  async getLivePrice(symbol: string, exchange: 'NSE' | 'BSE' = 'NSE'): Promise<{
    price: number;
    change: number;
    volume: number;
  }> {
    if (!this.isAuthenticated || !this.credentials?.accessToken) {
      throw new Error('Not authenticated with Angel One');
    }

    try {
      const symbolToken = await this.getSymbolToken(symbol, exchange);
      
      const response = await fetch(`${this.API_BASE}/rest/secure/angelbroking/market/v1/quote/`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.credentials.accessToken}`,
          'Accept': 'application/json',
          'X-UserType': 'USER',
          'X-SourceID': 'WEB',
          'X-ClientLocalIP': '192.168.1.1',
          'X-ClientPublicIP': '106.193.147.98',
          'X-MACAddress': '00-15-5D-B8-B9-22',
          'X-PrivateKey': this.credentials.apiKey
        },
        body: JSON.stringify({
          exchange: exchange,
          symboltoken: symbolToken
        })
      });

      if (!response.ok) {
        throw new Error(`Live price fetch failed: ${response.statusText}`);
      }

      const data = await response.json();
      if (data.status && data.data) {
        const quote = data.data;
        return {
          price: parseFloat(quote.ltp || quote.close),
          change: parseFloat(quote.netchange || 0),
          volume: parseInt(quote.totaltradedvalue || 0)
        };
      } else {
        throw new Error(`Live price fetch failed: ${data.message}`);
      }
    } catch (error) {
      console.error('Error fetching live price:', error);
      throw error;
    }
  }

  async subscribeToSymbol(symbol: string, exchange: 'NSE' | 'BSE' = 'NSE'): Promise<void> {
    if (!this.wsConnection || this.wsConnection.readyState !== WSClient.OPEN) {
      throw new Error('WebSocket not connected');
    }

    try {
      const symbolToken = await this.getSymbolToken(symbol, exchange);
      
      const subscription: MarketDataSubscription = {
        symbol,
        exchange,
        token: symbolToken
      };

      this.subscriptions.set(symbol, subscription);

      // Subscribe to live data stream
      const subscribeMessage = {
        a: 'subscribe',
        v: [[exchange, symbolToken]]
      };

      this.wsConnection.send(JSON.stringify(subscribeMessage));
      console.log(`Subscribed to ${symbol} on ${exchange}`);
    } catch (error) {
      console.error(`Error subscribing to ${symbol}:`, error);
      throw error;
    }
  }

  async unsubscribeFromSymbol(symbol: string): Promise<void> {
    const subscription = this.subscriptions.get(symbol);
    if (!subscription || !this.wsConnection) {
      return;
    }

    try {
      const unsubscribeMessage = {
        a: 'unsubscribe',
        v: [[subscription.exchange, subscription.token]]
      };

      this.wsConnection.send(JSON.stringify(unsubscribeMessage));
      this.subscriptions.delete(symbol);
      console.log(`Unsubscribed from ${symbol}`);
    } catch (error) {
      console.error(`Error unsubscribing from ${symbol}:`, error);
    }
  }

  private async getSymbolToken(symbol: string, exchange: 'NSE' | 'BSE'): Promise<string> {
    // This would typically involve a lookup table or API call to get symbol tokens
    // For now, returning the symbol as token (you'll need to implement proper token mapping)
    
    // Common NSE tokens (you should maintain a complete mapping)
    const symbolTokens: Record<string, string> = {
      'RELIANCE': '2885',
      'TCS': '11536',
      'HDFC': '1330',
      'INFY': '1594',
      'ICICIBANK': '4963',
      'HDFCBANK': '1333',
      'ITC': '424',
      'SBIN': '3045',
      'BHARTIARTL': '10604',
      'KOTAKBANK': '1922'
    };

    return symbolTokens[symbol] || symbol;
  }

  getAuthenticationStatus(): boolean {
    return this.isAuthenticated;
  }

  disconnect(): void {
    if (this.wsConnection) {
      this.wsConnection.close();
      this.wsConnection = null;
    }
    this.isAuthenticated = false;
    this.subscriptions.clear();
  }
}

export const angelOneService = new AngelOneService();