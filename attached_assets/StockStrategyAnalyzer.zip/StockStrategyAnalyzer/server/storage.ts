import { 
  users, 
  strategies, 
  trades, 
  backtests, 
  marketData,
  type User, 
  type InsertUser, 
  type Strategy, 
  type InsertStrategy,
  type Trade,
  type InsertTrade,
  type Backtest,
  type InsertBacktest,
  type MarketData,
  type InsertMarketData
} from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<User>): Promise<User | undefined>;
  
  // Strategy methods
  getStrategies(userId: number): Promise<Strategy[]>;
  getStrategy(id: number): Promise<Strategy | undefined>;
  createStrategy(strategy: InsertStrategy): Promise<Strategy>;
  updateStrategy(id: number, updates: Partial<Strategy>): Promise<Strategy | undefined>;
  deleteStrategy(id: number): Promise<boolean>;
  
  // Trade methods
  getTrades(userId: number, limit?: number): Promise<Trade[]>;
  getTradesByStrategy(strategyId: number): Promise<Trade[]>;
  createTrade(trade: InsertTrade): Promise<Trade>;
  updateTrade(id: number, updates: Partial<Trade>): Promise<Trade | undefined>;
  
  // Backtest methods
  getBacktests(userId: number): Promise<Backtest[]>;
  createBacktest(backtest: InsertBacktest): Promise<Backtest>;
  getBacktest(id: number): Promise<Backtest | undefined>;
  
  // Market data methods
  getMarketData(symbol: string, timeframe: string, limit?: number): Promise<MarketData[]>;
  insertMarketData(data: InsertMarketData): Promise<MarketData>;
  insertMarketDataBatch(data: InsertMarketData[]): Promise<MarketData[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private strategies: Map<number, Strategy>;
  private trades: Map<number, Trade>;
  private backtests: Map<number, Backtest>;
  private marketData: Map<string, MarketData>;
  private currentUserId: number;
  private currentStrategyId: number;
  private currentTradeId: number;
  private currentBacktestId: number;
  private currentMarketDataId: number;

  constructor() {
    this.users = new Map();
    this.strategies = new Map();
    this.trades = new Map();
    this.backtests = new Map();
    this.marketData = new Map();
    this.currentUserId = 1;
    this.currentStrategyId = 1;
    this.currentTradeId = 1;
    this.currentBacktestId = 1;
    this.currentMarketDataId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { 
      ...insertUser, 
      id, 
      createdAt: new Date(),
      isAuthenticated: false,
      sessionToken: null,
      angelOneClientId: null,
      angelOneApiKey: null,
      angelOneSecret: null
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async getStrategies(userId: number): Promise<Strategy[]> {
    return Array.from(this.strategies.values()).filter(
      (strategy) => strategy.userId === userId,
    );
  }

  async getStrategy(id: number): Promise<Strategy | undefined> {
    return this.strategies.get(id);
  }

  async createStrategy(insertStrategy: InsertStrategy): Promise<Strategy> {
    const id = this.currentStrategyId++;
    const strategy: Strategy = {
      ...insertStrategy,
      id,
      createdAt: new Date(),
      isActive: false,
      userId: insertStrategy.userId || null,
      parameters: insertStrategy.parameters || null
    };
    this.strategies.set(id, strategy);
    return strategy;
  }

  async updateStrategy(id: number, updates: Partial<Strategy>): Promise<Strategy | undefined> {
    const strategy = this.strategies.get(id);
    if (!strategy) return undefined;
    
    const updatedStrategy = { ...strategy, ...updates };
    this.strategies.set(id, updatedStrategy);
    return updatedStrategy;
  }

  async deleteStrategy(id: number): Promise<boolean> {
    return this.strategies.delete(id);
  }

  async getTrades(userId: number, limit = 50): Promise<Trade[]> {
    const userTrades = Array.from(this.trades.values())
      .filter((trade) => trade.userId === userId)
      .sort((a, b) => new Date(b.entryTime!).getTime() - new Date(a.entryTime!).getTime())
      .slice(0, limit);
    return userTrades;
  }

  async getTradesByStrategy(strategyId: number): Promise<Trade[]> {
    return Array.from(this.trades.values()).filter(
      (trade) => trade.strategyId === strategyId,
    );
  }

  async createTrade(insertTrade: InsertTrade): Promise<Trade> {
    const id = this.currentTradeId++;
    const trade: Trade = {
      ...insertTrade,
      id,
      entryTime: new Date(),
      exitTime: null,
      status: 'OPEN',
      userId: insertTrade.userId || null,
      strategyId: insertTrade.strategyId || null,
      metadata: insertTrade.metadata || null,
      exitPrice: null,
      pnl: null
    };
    this.trades.set(id, trade);
    return trade;
  }

  async updateTrade(id: number, updates: Partial<Trade>): Promise<Trade | undefined> {
    const trade = this.trades.get(id);
    if (!trade) return undefined;
    
    const updatedTrade = { ...trade, ...updates };
    this.trades.set(id, updatedTrade);
    return updatedTrade;
  }

  async getBacktests(userId: number): Promise<Backtest[]> {
    return Array.from(this.backtests.values()).filter(
      (backtest) => backtest.userId === userId,
    );
  }

  async createBacktest(insertBacktest: InsertBacktest): Promise<Backtest> {
    const id = this.currentBacktestId++;
    const backtest: Backtest = {
      ...insertBacktest,
      id,
      createdAt: new Date()
    };
    this.backtests.set(id, backtest);
    return backtest;
  }

  async getBacktest(id: number): Promise<Backtest | undefined> {
    return this.backtests.get(id);
  }

  async getMarketData(symbol: string, timeframe: string, limit = 100): Promise<MarketData[]> {
    return Array.from(this.marketData.values())
      .filter((data) => data.symbol === symbol && data.timeframe === timeframe)
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
      .slice(0, limit);
  }

  async insertMarketData(insertData: InsertMarketData): Promise<MarketData> {
    const id = this.currentMarketDataId++;
    const data: MarketData = { ...insertData, id };
    this.marketData.set(`${insertData.symbol}-${id}`, data);
    return data;
  }

  async insertMarketDataBatch(insertDataArray: InsertMarketData[]): Promise<MarketData[]> {
    const results: MarketData[] = [];
    for (const insertData of insertDataArray) {
      const result = await this.insertMarketData(insertData);
      results.push(result);
    }
    return results;
  }
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set(updates)
      .where(eq(users.id, id))
      .returning();
    return user || undefined;
  }

  async getStrategies(userId: number): Promise<Strategy[]> {
    return await db.select().from(strategies).where(eq(strategies.userId, userId));
  }

  async getStrategy(id: number): Promise<Strategy | undefined> {
    const [strategy] = await db.select().from(strategies).where(eq(strategies.id, id));
    return strategy || undefined;
  }

  async createStrategy(insertStrategy: InsertStrategy): Promise<Strategy> {
    const [strategy] = await db
      .insert(strategies)
      .values(insertStrategy)
      .returning();
    return strategy;
  }

  async updateStrategy(id: number, updates: Partial<Strategy>): Promise<Strategy | undefined> {
    const [strategy] = await db
      .update(strategies)
      .set(updates)
      .where(eq(strategies.id, id))
      .returning();
    return strategy || undefined;
  }

  async deleteStrategy(id: number): Promise<boolean> {
    const result = await db.delete(strategies).where(eq(strategies.id, id));
    return result.rowCount > 0;
  }

  async getTrades(userId: number, limit = 50): Promise<Trade[]> {
    return await db
      .select()
      .from(trades)
      .where(eq(trades.userId, userId))
      .orderBy(desc(trades.entryTime))
      .limit(limit);
  }

  async getTradesByStrategy(strategyId: number): Promise<Trade[]> {
    return await db.select().from(trades).where(eq(trades.strategyId, strategyId));
  }

  async createTrade(insertTrade: InsertTrade): Promise<Trade> {
    const [trade] = await db
      .insert(trades)
      .values(insertTrade)
      .returning();
    return trade;
  }

  async updateTrade(id: number, updates: Partial<Trade>): Promise<Trade | undefined> {
    const [trade] = await db
      .update(trades)
      .set(updates)
      .where(eq(trades.id, id))
      .returning();
    return trade || undefined;
  }

  async getBacktests(userId: number): Promise<Backtest[]> {
    return await db.select().from(backtests).where(eq(backtests.userId, userId));
  }

  async createBacktest(insertBacktest: InsertBacktest): Promise<Backtest> {
    const [backtest] = await db
      .insert(backtests)
      .values(insertBacktest)
      .returning();
    return backtest;
  }

  async getBacktest(id: number): Promise<Backtest | undefined> {
    const [backtest] = await db.select().from(backtests).where(eq(backtests.id, id));
    return backtest || undefined;
  }

  async getMarketData(symbol: string, timeframe: string, limit = 100): Promise<MarketData[]> {
    return await db
      .select()
      .from(marketData)
      .where(eq(marketData.symbol, symbol))
      .orderBy(desc(marketData.timestamp))
      .limit(limit);
  }

  async insertMarketData(insertData: InsertMarketData): Promise<MarketData> {
    const [data] = await db
      .insert(marketData)
      .values(insertData)
      .returning();
    return data;
  }

  async insertMarketDataBatch(insertDataArray: InsertMarketData[]): Promise<MarketData[]> {
    return await db
      .insert(marketData)
      .values(insertDataArray)
      .returning();
  }
}

export const storage = new DatabaseStorage();
