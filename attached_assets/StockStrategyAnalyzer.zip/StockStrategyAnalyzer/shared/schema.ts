import { pgTable, text, serial, integer, boolean, timestamp, decimal, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  angelOneClientId: text("angel_one_client_id"),
  angelOneApiKey: text("angel_one_api_key"),
  angelOneSecret: text("angel_one_secret"),
  isAuthenticated: boolean("is_authenticated").default(false),
  sessionToken: text("session_token"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const strategies = pgTable("strategies", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  name: text("name").notNull(),
  type: text("type").notNull(), // 'EMA_CROSSOVER', 'RSI_MEAN_REVERSION', 'MACD_MOMENTUM', 'CUSTOM'
  symbol: text("symbol").notNull(),
  timeframe: text("timeframe").notNull(), // '1min', '5min', '15min', '1hr', '1day'
  capital: decimal("capital", { precision: 12, scale: 2 }).notNull(),
  parameters: jsonb("parameters"), // Strategy-specific parameters
  isActive: boolean("is_active").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const trades = pgTable("trades", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  strategyId: integer("strategy_id").references(() => strategies.id),
  symbol: text("symbol").notNull(),
  type: text("type").notNull(), // 'BUY', 'SELL'
  quantity: integer("quantity").notNull(),
  entryPrice: decimal("entry_price", { precision: 12, scale: 2 }).notNull(),
  exitPrice: decimal("exit_price", { precision: 12, scale: 2 }),
  pnl: decimal("pnl", { precision: 12, scale: 2 }),
  status: text("status").default('OPEN'), // 'OPEN', 'CLOSED', 'PENDING'
  tradeMode: text("trade_mode").notNull(), // 'BACKTEST', 'PAPER', 'LIVE'
  entryTime: timestamp("entry_time").defaultNow(),
  exitTime: timestamp("exit_time"),
  metadata: jsonb("metadata"),
});

export const backtests = pgTable("backtests", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  strategyId: integer("strategy_id").references(() => strategies.id),
  symbol: text("symbol").notNull(),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date").notNull(),
  totalTrades: integer("total_trades").default(0),
  winRate: decimal("win_rate", { precision: 5, scale: 2 }),
  totalReturns: decimal("total_returns", { precision: 12, scale: 2 }),
  maxDrawdown: decimal("max_drawdown", { precision: 12, scale: 2 }),
  results: jsonb("results"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const marketData = pgTable("market_data", {
  id: serial("id").primaryKey(),
  symbol: text("symbol").notNull(),
  timestamp: timestamp("timestamp").notNull(),
  open: decimal("open", { precision: 12, scale: 2 }).notNull(),
  high: decimal("high", { precision: 12, scale: 2 }).notNull(),
  low: decimal("low", { precision: 12, scale: 2 }).notNull(),
  close: decimal("close", { precision: 12, scale: 2 }).notNull(),
  volume: integer("volume").notNull(),
  timeframe: text("timeframe").notNull(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertStrategySchema = createInsertSchema(strategies).omit({
  id: true,
  createdAt: true,
});

export const insertTradeSchema = createInsertSchema(trades).omit({
  id: true,
  entryTime: true,
  exitTime: true,
});

export const insertBacktestSchema = createInsertSchema(backtests).omit({
  id: true,
  createdAt: true,
});

export const insertMarketDataSchema = createInsertSchema(marketData).omit({
  id: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Strategy = typeof strategies.$inferSelect;
export type InsertStrategy = z.infer<typeof insertStrategySchema>;
export type Trade = typeof trades.$inferSelect;
export type InsertTrade = z.infer<typeof insertTradeSchema>;
export type Backtest = typeof backtests.$inferSelect;
export type InsertBacktest = z.infer<typeof insertBacktestSchema>;
export type MarketData = typeof marketData.$inferSelect;
export type InsertMarketData = z.infer<typeof insertMarketDataSchema>;
